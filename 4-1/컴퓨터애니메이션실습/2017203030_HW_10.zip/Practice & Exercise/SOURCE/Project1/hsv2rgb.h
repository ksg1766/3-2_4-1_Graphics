#ifndef _COLORMODEL_H_
#define _COLORMODEL_H_

void	HSV2RGB(double	hsv[3], double	 rgb[3]);
void	HSV2RGB(float	hsv[3], float	 rgb[3]);

#endif // _COLOR_MODEL_H_